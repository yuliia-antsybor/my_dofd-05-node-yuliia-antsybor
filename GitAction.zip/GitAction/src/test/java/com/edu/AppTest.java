package com.edu;

import org.junit.Assert;
import org.junit.Test;

public class AppTest {

    @Test
    public void testApp() {
        System.out.println("class AppTest; method testApp()");
        //
        Assert.assertTrue(true);
    }
}
